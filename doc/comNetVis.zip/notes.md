Notes:
- first image has bad resolution. I'll have to use a large screen desktop to get a better image. 
- I'll change the screenshots when we agree on a final version for the interface.
- I ignored the text areas with information about the best sphere and the centroid because I am not sure we will keep them.
- If you wish to use the communicability distances for any reason, just write me and I'll enable them again.
- I simplified the parametrization (e.g. you do not choose the number of initializations for MDS). If you find any setting in which you want faster results, I'll experiment in the local scripts and change the general settings or enable fine-tuning on the interface.
